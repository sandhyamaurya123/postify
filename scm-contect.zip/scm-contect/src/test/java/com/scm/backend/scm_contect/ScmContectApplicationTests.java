package com.scm.backend.scm_contect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScmContectApplicationTests {

	@Test
	void contextLoads() {
	}

}
